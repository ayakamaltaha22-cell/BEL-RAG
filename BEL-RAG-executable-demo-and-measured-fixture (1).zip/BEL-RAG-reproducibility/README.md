# BEL-RAG reproducibility-study scaffold

**Status: proposed, not a replication of the manuscript's reported experiments.**

This archive includes a machine-readable *reference* configuration, proposed prompts, dataset manifest templates, and a small executable utility module. The numerical values for C, tau, lambda, maximum leased passages and related grids are user-confirmed as adopted for a proposed configuration, but no original experiment logs, fitted calibrator, exact dataset snapshots, original source code, or per-example outputs were supplied to this package.

## Contents
- `configs/reference.yaml`: parameter values, documented original settings, and explicit unresolved fields.
- `configs/search_grids.yaml`: proposed tuning grids.
- `prompts/`: three proposed prompt templates.
- `data/dataset_manifest.json`: dataset names, public landing pages, and missing release/checksum fields.
- `src/reference_utils.py`: basic prior correction, posterior update, and normalization utilities; **not the complete BEL-RAG system**.
- `results/STATUS.md`: explanation of missing experimental outputs.

## Quick smoke test
`python src/reference_utils.py`

## Before publishing claims of reproducibility
Pin exact dataset/model revisions and hashes; fill dataset counts, original prompts, fitted calibration coefficients and normalization statistics; implement PAR, EL, CA, CG and baseline pipelines; archive raw logs, predictions, per-seed metrics, policy cases and statistical scripts; rerun all manuscript tables. Do not cite this scaffold as evidence that the manuscript's numbers have been replicated.

## GitHub
Not published. Create a GitHub repository and upload these files, or connect the GitHub app for assistance. Do not insert a repository URL in the manuscript until publication is verified.

## Executable synthetic demonstration (added)

Run `python src/demo_pipeline.py` (requires `pip install -r requirements-demo.txt`).
Run `python tests/test_demo.py` for an end-to-end smoke test.
Actual outputs from the synthetic demonstration are saved under `results/demo/`:
`demo_metrics.json`, `per_example.csv`, `traces.json`, `demo_calibrator.json`, `fixture.json`.

**Critical scope limits:** This is a lightweight *partial reference implementation*, not the
full manuscript BEL-RAG system. It demonstrates policy prefiltering, TF-IDF candidate retrieval,
a toy fitted logistic evidence model, prior-corrected sequential odds updating, bounded
leasing, exhaustive support-subset auditing, a CFS decision and extractive answer reporting.
It does NOT implement the manuscript's BGE/FAISS retriever, Mistral generation, cross-encoder,
NLI, calibrated conditional evidence-dependence modeling, full utility lookahead, true
multi-round audit feedback, or benchmark adapters. Its toy calibration features and labels
are deliberately synthetic and are **not** scientifically valid estimates of passage
entailment. Results cannot be cited as the paper's benchmark results or used to validate
Tables 1–5. The sample outputs are measured by running the demo, not fabricated, but are
limited to six synthetic examples; in-sample calibration scores are not held-out results.
The main reference YAML remains a proposed full-scale configuration, not an executable
configuration for this reduced demonstration.
